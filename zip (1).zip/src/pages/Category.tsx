import { motion } from 'motion/react';
import { Folder } from 'lucide-react';

const CATEGORIES = [
  { name: '前端开发', count: 42, description: 'React, Vue, 构建工具及性能优化相关', color: 'from-blue-500/20 to-purple-500/20', border: 'border-blue-500/30' },
  { name: '后端开发', count: 28, description: 'Node.js, 数据库, 架构与微服务', color: 'from-emerald-500/20 to-teal-500/20', border: 'border-emerald-500/30' },
  { name: '随笔杂谈', count: 16, description: '生活、阅读与个人思考记录', color: 'from-orange-500/20 to-red-500/20', border: 'border-orange-500/30' },
  { name: '生活日常', count: 12, description: '游记、摄影与日常碎片', color: 'from-pink-500/20 to-rose-500/20', border: 'border-pink-500/30' },
  { name: '学习笔记', count: 24, description: '读书笔记与新技术探索', color: 'from-indigo-500/20 to-blue-500/20', border: 'border-indigo-500/30' },
  { name: '架构设计', count: 8, description: '系统设计、设计模式与工程化', color: 'from-purple-500/20 to-pink-500/20', border: 'border-purple-500/30' }
];

export default function Category() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-12 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl font-black text-white mb-4 drop-shadow-[0_0_15px_rgba(168,85,247,0.4)]"
        >
          文章分类
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-slate-400"
        >
          将知识进行系统化的整理与归档
        </motion.p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10">
        {CATEGORIES.map((cat, i) => (
          <motion.div
            key={cat.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md hover:bg-white/10 transition-all cursor-pointer group relative overflow-hidden`}
          >
            <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${cat.color} blur-2xl rounded-full opacity-50 group-hover:opacity-100 transition-opacity`}></div>
            <div className="relative z-10">
               <div className="flex items-center justify-between mb-4">
                 <div className={`w-10 h-10 rounded-xl bg-white/5 border ${cat.border} flex items-center justify-center text-white/80 group-hover:text-white transition-colors`}>
                   <Folder className="w-5 h-5" />
                 </div>
                <span className="text-2xl font-black text-white/20 group-hover:text-white/40 transition-colors">
                   --
                 </span>
               </div>
               <h3 className="text-xl font-bold text-slate-200 group-hover:text-purple-300 transition-colors mb-2">
                 {cat.name}
               </h3>
               <p className="text-sm text-slate-500">
                 {cat.description}
               </p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
